import React from "react";

function About() {
  return (
    <div className="m-5 p-5  bg-white rounded shadow ">
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. At aliquid
      obcaecati quod est excepturi praesentium possimus quas corporis ducimus.
      Inventore adipisci at modi neque architecto dolores tempora accusamus
      corporis. Exercitationem.
    </div>
  );
}

export default About;
